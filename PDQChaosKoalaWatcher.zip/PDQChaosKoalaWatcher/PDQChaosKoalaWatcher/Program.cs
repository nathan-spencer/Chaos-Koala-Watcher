﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PDQChaosKoalaWatcher
{
    /*
     * Author: Nathan Spencer
     * Date: 04/20/2019
     * Description: Program created as part of PDQ application process to monitor a directory for file changes.
     * Link: https://bitbucket.org/pdqdev/pdq-filewatcher-public/src
     * Requirements:
     * The program takes 2 arguments, the directory to watch and a file pattern, example: program.exe "c:\file folder" *.txt
     * The path may be an absolute path, relative to the current directory, or UNC.
     * Use the modified date of the file as a trigger that the file has changed.
     * Check for changes every 10 seconds.
     * When a file is created output a line to the console with its name and how many lines are in it.
     * When a file is modified output a line with its name and the change in number of lines (use a + or - to indicate more or less).
     * When a file is deleted output a line with its name.
     * Files will be ASCII or UTF-8 and will use Windows line separators (CR LF).
     * Multiple files may be changed at the same time, can be up to 2 GB in size, and may be locked for several seconds at a time.
     * Use multiple threads so that the program doesn't block on a single large or locked file.
     * Program will be run on Windows 10.
     * File names are case insensitive.
     */
    class Program
    {
        private static readonly int ThreadDelay = 10000; //10000ms = 10 seconds
        private static readonly bool AddLineLabels = false;
        private static string FilePattern;
        private static DirectoryInfo WatchDirectory;
        private static List<FileData> LastPulledFileInfo;
        private static string Create, Modify, Delete;

        static void Main(string[] args)
        {
            try
            {
                //Check input parameters and initialize global variables
                if (args == null || args.Length != 2)
                {
                    throw new Exception("Wrong number of parameters provided. Expecting directory and file pattern.");
                }

                string watchDirectoryPath = args[0];
                if (!Directory.Exists(watchDirectoryPath))
                {
                    throw new Exception($"Could not find directory \"{watchDirectoryPath}\".");
                }
                WatchDirectory = new DirectoryInfo(watchDirectoryPath);

                //Save the file pattern. Check if valid?
                FilePattern = args[1];

                //Set output format
                if (AddLineLabels)
                {
                    Create = "Created: {0} Lines: {1}";
                    Modify = "Modified: {0} Lines: {1}";
                    Delete = "Deleted: {0}";
                }
                else
                {
                    Create = Modify = "{0} {1}";
                    Delete = "{0}";
                }

                //Gather initial data on directory files.
                LastPulledFileInfo = GetFileInfo(new List<FileData>());

                //Every 10 seconds start a new thread to check for file changes in directory.
                while (true)
                {
                    new Thread(() => ProcessFileChanges()).Start();
                    Thread.Sleep(ThreadDelay);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Press any key to close.");
                Console.ReadKey();
            }
        }

        private static void ProcessFileChanges()
        {
            //Get new and old info to compair. Save new info as last pulled file info.
            List<FileData> oldInfo = new List<FileData>(LastPulledFileInfo ?? new List<FileData>());
            List<FileData> newInfo = GetFileInfo(oldInfo);
            LastPulledFileInfo = new List<FileData>(newInfo);

            //Check each file to see if it is newly created or modified.
            foreach (FileData file in newInfo)
            {
                FileData oldFile = oldInfo.FirstOrDefault(o => o.CaseInsensitiveName == file.CaseInsensitiveName);
                //If old file not found then file was newly created.
                if (oldFile == null)
                {
                    Console.WriteLine(Create, file.Name, file.Lines);
                }
                //If last write times don't match then file was modified.
                else if (file.LastModified != oldFile.LastModified)
                {
                    int lineCountChange = file.Lines - oldFile.Lines;
                    Console.WriteLine(Modify, file.Name, lineCountChange.ToString("+0;-#"));
                }
            }

            //Check for files that exist in old info, but not in new info. Display as deleted files.
            foreach (FileData deletedFile in oldInfo.Where(o => !newInfo.Any(n => n.CaseInsensitiveName == o.CaseInsensitiveName)))
            {
                Console.WriteLine(Delete, deletedFile.Name);
            }
        }

        private static List<FileData> GetFileInfo(List<FileData> oldInfo)
        {
            //Get list of files that match pattern in directory. Start a task for each file to get the number of lines.
            if (oldInfo == null) { oldInfo = new List<FileData>(); }
            FileInfo[] newInfoArray = WatchDirectory.GetFiles(FilePattern);
            List<FileData> newInfo = new List<FileData>();
            Task[] fileTasks = new Task[newInfoArray.Length];
            for (int i = 0; i < newInfoArray.Length; i++)
            {
                //Avoid recounting lines when unnecessary. Use old line count if exists and file is unchanged.
                //Max int value 2,147,483,647. Max number of lines in 2GB txt file is ~1,000,000,000 @ 2 bytes per line.
                FileData file = new FileData(newInfoArray[i]);
                Task task = new Task(() =>
                {
                    FileData oldFile = oldInfo.FirstOrDefault(o => o.CaseInsensitiveName == file.CaseInsensitiveName);
                    if (oldFile != null && oldFile.LastModified == file.LastModified)
                    {
                        file.Lines = oldFile.Lines;
                    }
                    else
                    {
                        try { file.Lines = File.ReadLines(file.FullName).Count(); }
                        catch { file.Lines = 0; }
                    }
                    lock (newInfo)
                    {
                        newInfo.Add(file);
                    }
                });
                fileTasks[i] = task;
            }
            //Start and wait for all tasks to complete before returning.
            foreach (Task task in fileTasks)
            {
                task.Start();
            }
            Task.WaitAll(fileTasks);
            return newInfo;
        }
    }

    public class FileData //Class to store important file info.
    {
        public string Name { get; set; }
        public string CaseInsensitiveName { get { return Name.ToLower(); } }
        public string FullName { get; set; }
        public DateTime LastModified { get; set; }
        public int Lines { get; set; }

        public FileData(FileInfo fileInfo)
        {
            Name = fileInfo.Name;
            FullName = fileInfo.FullName;
            LastModified = fileInfo.LastWriteTime;
            Lines = 0;
        }
    }
}